package com.aman;

import org.apache.log4j.Logger;
import org.aspectj.lang.JoinPoint;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

@Aspect
public class DropLog {
	
	
	@Pointcut("execution(* com.aman.*.*(..))")
	   private void selectAll(){}
	
	@Before("selectAll()")
	public void enterExitLog(JoinPoint jp){
		  Logger log = Logger.getLogger(jp.getClass().getName());
		  log.info("method executed"+jp.getSignature());
		 System.out.println("Going to setup student profile.");
		
		 log.info("setup done");
	}
}
