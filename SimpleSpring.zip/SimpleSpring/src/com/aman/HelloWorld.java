package com.aman;

import org.apache.log4j.Logger;
import org.aspectj.lang.annotation.AdviceName;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.annotation.Before;
import org.aspectj.lang.annotation.Pointcut;

public class HelloWorld {
	
	   static Logger log = Logger.getLogger(HelloWorld.class.getName());
	   private String message;
	   
	   
	  
	   public void setMessage(String message){
	      this.message  = message;
	   }
	   public void getMessage() {
		   log.info("****************hbbdhbh*************");
		   log.info("Your Message : " + message);
	   }
	}